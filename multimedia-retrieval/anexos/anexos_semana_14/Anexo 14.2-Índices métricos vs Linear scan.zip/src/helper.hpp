// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#pragma once

#include <string>
#include <vector>
#include <sstream>

int parse_int(const std::string &string);

double parse_double(const std::string &string);

bool is_int(const std::string &string);

std::vector<std::string> get_args_vector(int argc, char **argv);

bool starts_with(const std::string &string, const std::string &prefix);

bool existeArchivo(const std::string &filename);

std::vector<int> seleccionarNumerosRandomSinRepetir(int cantidad, int hastaSinIncluir);

template<typename T>
std::string vectorToString(const std::vector<T> &vector) {
	std::stringstream ss;
	ss << "[";
	for (std::size_t i = 0; i < vector.size(); ++i) {
		if (i > 0)
			ss << ", ";
		ss << vector[i];
	}
	ss << "]";
	return ss.str();
}

