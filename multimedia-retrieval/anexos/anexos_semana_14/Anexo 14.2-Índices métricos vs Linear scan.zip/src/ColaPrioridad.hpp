// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#pragma once

#include <vector>
#include <memory>

class Queue;

class ColaPrioridad {
public:
	ColaPrioridad();

	void agregar(double prioridad, int id_objeto);

	double topPrioridad();

	void borrarTop();

	int size();

	void vaciarCola(double *prioridades, int *idsObjetos);

	virtual ~ColaPrioridad();

private:
	std::shared_ptr<Queue> queue;
};
