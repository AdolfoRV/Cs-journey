// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#pragma once

#include "Indice.hpp"

class IndiceLaesa: public Indice {
public:
	IndiceLaesa(int cantidadPivotes);

	virtual void construir(Dataset *descriptores, Distancia *funcionDistancia);

	virtual void busquedaNN(float *queryVector, int cantidadNN, int *resultadoIds, double *resultadoDistancias);

	virtual void imprimirStats();

	virtual ~IndiceLaesa();

private:
	double* getArrayDistanciasObjetoACadaPivote(int idObjeto);
	void calcularDistanciasVectorACadaPivote(float *vector, double *arrayDistanciasACadaPivote);
	double calcularCotaInferior(double *distanciasQueryACadaPivote, int idObjeto, double distanciaUmbral);

	Dataset *descriptores;
	Distancia *funcionDistancia;
	int cantidadPivotes;
	std::vector<int> idsPivotes;
	std::vector<double> distanciasObj2pivotes;
	long long cantidadQueries;
};
