// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#pragma once

#include "Indice.hpp"

class IndiceLinearScan: public Indice {
public:
	IndiceLinearScan();

	virtual void construir(Dataset *descriptores, Distancia *funcionDistancia);

	virtual void busquedaNN(float *queryVector, int cantidadNN, int *resultadoIds, double *resultadoDistancias);

	virtual void imprimirStats();

	virtual ~IndiceLinearScan();

private:
	Dataset *descriptores;
	Distancia *funcionDistancia;
	long long cantidadQueries;
};
