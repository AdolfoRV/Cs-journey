// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#include "Tiempo.hpp"

Tiempo::Tiempo() {
	inicio = std::chrono::high_resolution_clock::now();
}

void Tiempo::reset() {
	inicio = std::chrono::high_resolution_clock::now();
}

int Tiempo::milisegundos() {
	std::chrono::time_point<std::chrono::high_resolution_clock> fin = std::chrono::high_resolution_clock::now();
	int milisegundos = std::chrono::duration_cast<std::chrono::milliseconds>(fin - inicio).count();
	return milisegundos;
}

std::string Tiempo::timeToString() {
	int ms = milisegundos();
	if (ms > 500)
		return std::to_string(ms / 1000) + "." + std::to_string((ms % 1000) / 100) + " s.";
	return std::to_string(ms) + " ms.";
}
