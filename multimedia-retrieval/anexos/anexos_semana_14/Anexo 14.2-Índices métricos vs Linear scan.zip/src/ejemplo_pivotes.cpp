// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "Dataset.hpp"
#include "Distancia.hpp"
#include "helper.hpp"
#include "IndiceLaesa.hpp"
#include "IndiceLinearScan.hpp"
#include "ResultadoKnn.hpp"
#include "Tiempo.hpp"

namespace {

Distancia* parseDistancia(const std::string &nombreDistancia, int dimensiones) {
	if (nombreDistancia == "L1") {
		return new DistanciaL1(dimensiones);
	} else if (nombreDistancia == "L2") {
		return new DistanciaL2(dimensiones);
	} else if (nombreDistancia == "Lmax") {
		return new DistanciaLmax(dimensiones);
	} else if (nombreDistancia.at(0) == 'L') {
		int orden = parse_double(nombreDistancia.substr(1));
		return new DistanciaLP(orden, dimensiones);
	} else {
		throw std::runtime_error("no encuentro distancia " + nombreDistancia);
	}
}

Indice* parseIndice(const std::string &nombreIndice) {
	if (nombreIndice == "LINEAR") {
		return new IndiceLinearScan();
	} else if (starts_with(nombreIndice, "LAESA_")) {
		int cantidadPivotes = parse_int(nombreIndice.substr(6));
		return new IndiceLaesa(cantidadPivotes);
	} else {
		throw std::runtime_error("no encuentro indice " + nombreIndice);
	}
}

void ejemplo(const std::string &filenameQ, const std::string &filenameR, int dimensiones,
		const std::string &nombreDistancia, int cantidadNN, const std::string &nombreIndice) {
	//leer los datos
	Dataset *queries = Dataset::cargarDescriptores(filenameQ, dimensiones);
	Dataset *descriptores = Dataset::cargarDescriptores(filenameR, dimensiones);
	//
	Distancia *funcionDistancia = parseDistancia(nombreDistancia, dimensiones);
	//construir el indice
	Indice *indice = parseIndice(nombreIndice);
	indice->construir(descriptores, funcionDistancia);
	//donde se guardaran todos los NN con sus distancias
	int cantidadQueries = queries->getNumVectores();
	if (cantidadNN <= 0)
		cantidadNN = 1;
	ResultadoKnn resultadoKNN(cantidadQueries, cantidadNN);
	//resolver las busquedas
	Tiempo tiempo;
	//recorrer q
	for (int i = 0; i < queries->getNumVectores(); ++i) {
		//el vector de consulta
		float *queryVector = queries->getVector(i);
		//donde se va a guardar el resultado
		int *resultadoIds = resultadoKNN.ids(i);
		double *resultadoDistancias = resultadoKNN.distancias(i);
		//resolver la busqueda con el indice
		indice->busquedaNN(queryVector, cantidadNN, resultadoIds, resultadoDistancias);
	}
	std::cout << "tiempo busqueda: " << tiempo.timeToString() << std::endl;
	indice->imprimirStats();
	//imprimir resultado
	for (int i = 0; i < 10; ++i) {
		std::cout << i << " " << resultadoKNN.toString(i) << std::endl;
	}
}

}

int main(int argc, char **argv) {
	try {
		std::vector<std::string> args = get_args_vector(argc, argv);
		std::cout << "CC5213 - Recuperación de Información Multimedia" << std::endl;
		std::cout << "Ejemplo Índices métricos" << std::endl;
		if (args.size() < 7) {
			std::cout << " Usos: " << args[0] << std::endl;
			std::cout << "   -q      [archivo binario]       archivo con vectores de consulta" << std::endl;
			std::cout << "   -r      [archivo binario]       archivo con vectores del dataset" << std::endl;
			std::cout << "   -dim    [numero]                dimension de los vectores" << std::endl;
			std::cout << "   -dist   [L1|L2|Lmax|LP]         funcion para comparar vectores" << std::endl;
			std::cout << "   -knn    [numNN]                 cantidad de vecinos mas cercanos" << std::endl;
			std::cout << "   -indice [LINEAR|LAESA_pivotes]  indice a usar" << std::endl;
			return 0;
		}
		std::string filenameQ;
		std::string filenameR;
		int dimensiones = 0;
		std::string nombreDistancia;
		int cantidadNN = 0;
		std::string nombreIndice;
		for (unsigned int i = 1; i < args.size(); ++i) {
			std::string arg = args[i];
			if (arg == "-q") {
				filenameQ = args[++i];
			} else if (arg == "-r") {
				filenameR = args[++i];
			} else if (arg == "-dim") {
				dimensiones = parse_int(args[++i]);
			} else if (arg == "-dist") {
				nombreDistancia = args[++i];
			} else if (arg == "-knn") {
				cantidadNN = parse_int(args[++i]);
			} else if (arg == "-indice") {
				nombreIndice = args[++i];
			} else {
				std::cout << " parametro desconocido: " << arg << std::endl;
				return 1;
			}
		}
		ejemplo(filenameQ, filenameR, dimensiones, nombreDistancia, cantidadNN, nombreIndice);
	} catch (const std::exception &ex) {
		std::cout << "Ha ocurrido un ERROR: " << ex.what() << std::endl;
	} catch (...) {
		std::cout << "Ha ocurrido ERROR desconocido" << std::endl;
	}
	return 0;
}
