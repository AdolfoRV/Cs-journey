// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#include "helper.hpp"
#include <iostream>
#include <fstream>
#include <sys/stat.h>
#include <random>

int parse_int(const std::string &string) {
	std::size_t next_position = 0;
	int n;
	try {
		n = std::stoi(string, &next_position, 10);
	} catch (...) {
		throw std::logic_error("invalid number \"" + string + "\"");
	}
	if (next_position != string.length())
		throw std::logic_error("invalid number \"" + string + "\"");
	return n;
}

double parse_double(const std::string &string) {
	std::size_t next_position = 0;
	double n;
	try {
		n = std::stod(string, &next_position);
	} catch (...) {
		throw std::logic_error("invalid number \"" + string + "\"");
	}
	if (next_position != string.length())
		throw std::logic_error("invalid number \"" + string + "\"");
	return n;
}

bool is_int(const std::string &string) {
	if (string.length() == 0)
		return false;
	for (char c : string) {
		if (!std::isdigit(c))
			return false;
	}
	return true;
}

std::vector<std::string> get_args_vector(int argc, char **argv) {
	std::vector<std::string> args;
	for (int i = 0; i < argc; ++i) {
		args.push_back(std::string(argv[i]));
	}
	return args;
}
bool starts_with(const std::string &string, const std::string &prefix) {
	return (string.rfind(prefix, 0) == 0);
}
bool existeArchivo(const std::string &filename) {
	struct stat st;
	if (stat(filename.c_str(), &st) == 0)
		return S_ISREG(st.st_mode) ? true : false;
	return false;
}

std::vector<int> seleccionarNumerosRandomSinRepetir(int cantidad, int hastaSinIncluir) {
	if (cantidad > hastaSinIncluir)
		throw std::logic_error(
				"no puedo escoger " + std::to_string(cantidad) + " de " + std::to_string(hastaSinIncluir) + "\"");
	std::random_device r;
	std::default_random_engine e1(r());
	std::uniform_int_distribution<int> uniform_dist(0, hastaSinIncluir);
	std::vector<int> lista;
	while ((int) lista.size() < cantidad) {
		int nextInt = uniform_dist(e1);
		bool existe = false;
		for (int n : lista) {
			if (nextInt == n)
				existe = true;
		}
		if (!existe)
			lista.push_back(nextInt);
	}
	return lista;
}

