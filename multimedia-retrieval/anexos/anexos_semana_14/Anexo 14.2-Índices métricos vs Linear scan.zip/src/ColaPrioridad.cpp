// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#include <queue>

#include "ColaPrioridad.hpp"

class Candidato {
public:
	Candidato(double prioridad, int idObjeto) :
			prioridad(prioridad), idObjeto(idObjeto) {
	}

	bool operator<(const Candidato &otro) const {
		return prioridad < otro.prioridad;
	}

	double prioridad;
	int idObjeto;
};

class Queue {
public:
	std::priority_queue<Candidato> maxHeap;
};

ColaPrioridad::ColaPrioridad() {
	this->queue = std::make_shared<Queue>();
}

void ColaPrioridad::agregar(double prioridad, int idObjeto) {
	Candidato c(prioridad, idObjeto);
	this->queue->maxHeap.push(c);
}

double ColaPrioridad::topPrioridad() {
	return this->queue->maxHeap.top().prioridad;
}

void ColaPrioridad::borrarTop() {
	this->queue->maxHeap.pop();
}

int ColaPrioridad::size() {
	return this->queue->maxHeap.size();
}

void ColaPrioridad::vaciarCola(double *prioridades, int *idsObjetos) {
	//copiar los objetos desde la cola a los array de salida
	//notar que los candidatos salen en orden inverso desde la cola
	while (this->queue->maxHeap.size() > 0) {
		int posicion = this->queue->maxHeap.size() - 1;
		prioridades[posicion] = this->queue->maxHeap.top().prioridad;
		idsObjetos[posicion] = this->queue->maxHeap.top().idObjeto;
		this->queue->maxHeap.pop();
	}
}

ColaPrioridad::~ColaPrioridad() {
}

