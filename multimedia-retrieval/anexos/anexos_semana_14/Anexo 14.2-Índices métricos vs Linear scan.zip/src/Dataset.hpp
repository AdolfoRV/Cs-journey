// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#pragma once

#include <string>
#include <vector>

class Dataset {
public:
	static Dataset* cargarDescriptores(const std::string &filename, int dimensiones);

	Dataset(int numVectores, int dimensiones);

	int getNumVectores() const;

	int getDimensiones() const;

	float* getVector(int numero);

	~Dataset();

private:
	int numVectores;
	int dimensiones;
	float *arrayVectores;
};

