// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#pragma once

#include <string>
#include <vector>

class ResultadoKnn {
public:
	ResultadoKnn(int cantidadQueries, int cantidadNns);

	int getCantidadQueries() const;

	int getCantidadNns() const;

	int* ids(int numero);

	double* distancias(int numero);

	std::string toString(int numero);

private:
	int cantidadQueries;
	int cantidadNN;
	std::vector<int> idsNns;
	std::vector<double> distanciasNns;
};
