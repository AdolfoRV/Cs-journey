// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#include "IndiceLaesa.hpp"

#include "helper.hpp"

#include <iostream>
#include <cmath>

#include "ColaPrioridad.hpp"
#include "Tiempo.hpp"

IndiceLaesa::IndiceLaesa(int cantidadPivotes) :
		descriptores(nullptr), funcionDistancia(nullptr), cantidadPivotes(cantidadPivotes), cantidadQueries(0) {
	if (this->cantidadPivotes <= 0)
		this->cantidadPivotes = 1;
}

double* IndiceLaesa::getArrayDistanciasObjetoACadaPivote(int idObjeto) {
	if (idObjeto < 0 || idObjeto >= this->descriptores->getNumVectores())
		throw std::runtime_error("fuera de rango " + idObjeto);
	//fila de la tabla donde se guardan las distancias del objeto con cada pivote
	return this->distanciasObj2pivotes.data() + idObjeto * this->cantidadPivotes;
}

void IndiceLaesa::calcularDistanciasVectorACadaPivote(float *vector, double *arrayDistanciasACadaPivote) {
	for (int j = 0; j < this->cantidadPivotes; ++j) {
		float *pivote = this->descriptores->getVector(this->idsPivotes[j]);
		double dist = this->funcionDistancia->distancia(vector, pivote);
		arrayDistanciasACadaPivote[j] = dist;
	}
}

void IndiceLaesa::construir(Dataset *descriptores, Distancia *funcionDistancia) {
	this->descriptores = descriptores;
	this->funcionDistancia = funcionDistancia;
	if (this->cantidadPivotes < 0 || this->cantidadPivotes > descriptores->getNumVectores())
		throw std::runtime_error("fuera de rango " + this->cantidadPivotes);
	Tiempo tiempo;
	//escoger pivotes
	this->idsPivotes = seleccionarNumerosRandomSinRepetir(this->cantidadPivotes, descriptores->getNumVectores());
	std::cout << "idsPivotes=" << vectorToString(this->idsPivotes) << std::endl;
	//crear la tabla de pivotes
	this->distanciasObj2pivotes.resize(descriptores->getNumVectores() * this->cantidadPivotes);
	//llenar la tabla
	for (int i = 0; i < descriptores->getNumVectores(); ++i) {
		//i-esimo objeto
		float *vector = descriptores->getVector(i);
		//fila de la tabla donde se guardan las distancias del objeto con cada pivote
		double *arrayDistanciasACadaPivote = getArrayDistanciasObjetoACadaPivote(i);
		//calcular la distancia del objeto con cada pivote
		calcularDistanciasVectorACadaPivote(vector, arrayDistanciasACadaPivote);
	}
	std::cout << "construccion: " << tiempo.timeToString() << " distancias="
			<< this->funcionDistancia->getCantidadEvaluaciones() << std::endl;
	this->funcionDistancia->resetCantidadEvaluaciones();
}

double IndiceLaesa::calcularCotaInferior(double *distanciasQueryACadaPivote, int idObjeto, double distanciaUmbral) {
	double *arrayDistanciasACadaPivote = getArrayDistanciasObjetoACadaPivote(idObjeto);
	double maxCotaInferior = 0;
	for (int j = 0; j < this->cantidadPivotes; ++j) {
		double cotaInferior = std::abs(distanciasQueryACadaPivote[j] - arrayDistanciasACadaPivote[j]);
		if (cotaInferior > maxCotaInferior) {
			maxCotaInferior = cotaInferior;
			//si se supera el umbral, retornar de inmediato porque idObjeto no es relevante
			if (maxCotaInferior >= distanciaUmbral)
				return maxCotaInferior;
		}
	}
	return maxCotaInferior;
}

void IndiceLaesa::busquedaNN(float *queryVector, int cantidadNN, int *resultadoIds, double *resultadoDistancias) {
	this->cantidadQueries += 1;
	this->funcionDistancia->resetDistanciaUmbral();
	//crear un array para guardar las distancias de la query con cada pivote
	std::vector<double> distanciasQueryACadaPivote(this->cantidadPivotes);
	//calcular la distancia de la query con cada pivote
	calcularDistanciasVectorACadaPivote(queryVector, distanciasQueryACadaPivote.data());
	//cola de prioridad (max-heap)
	ColaPrioridad colaPrioridad;
	//recorro los primeros cantidadNN agregándolos a la cola de prioridad
	for (int i = 0; i < cantidadNN && i < this->descriptores->getNumVectores(); ++i) {
		float *vectorR = this->descriptores->getVector(i);
		double distancia = this->funcionDistancia->distancia(queryVector, vectorR);
		//agregarlo a la cola de prioridad
		colaPrioridad.agregar(distancia, i);
	}
	//la cola está llena, el umbral es el candidato de mayor distancia
	double distanciaUmbral = colaPrioridad.topPrioridad();
	this->funcionDistancia->setDistanciaUmbral(distanciaUmbral);
	//recorro desde cantidadNN en adelante
	for (int i = cantidadNN; i < this->descriptores->getNumVectores(); ++i) {
		//cota inferior
		double cotaInferior = calcularCotaInferior(distanciasQueryACadaPivote.data(), i, distanciaUmbral);
		//si la cota inferior es mayor o igual al umbral este vector no puede ser relevante
		if (cotaInferior >= distanciaUmbral)
			continue;
		//obtener el i-esimo vector
		float *vectorR = this->descriptores->getVector(i);
		//calcular distancia de la consulta al vector
		double distancia = this->funcionDistancia->distancia(queryVector, vectorR);
		//si la distancia no es mejor que el umbral de corte se descarta el objeto, si no se agrega al heap
		if (distancia >= distanciaUmbral)
			continue;
		//sacar el top del heap (mayor distancia)
		colaPrioridad.borrarTop();
		//agregar el nuevo
		colaPrioridad.agregar(distancia, i);
		//actualizar el umbral con el nuevo top del heap
		distanciaUmbral = colaPrioridad.topPrioridad();
		//actualizar el umbral de corte en la funcion de distancia
		this->funcionDistancia->setDistanciaUmbral(distanciaUmbral);
	}
	//copiar los objetos desde la cola a los array de salida
	colaPrioridad.vaciarCola(resultadoDistancias, resultadoIds);
}

void IndiceLaesa::imprimirStats() {
	//cantidad de evaluaciones comparado con el linear scan
	double fraction = this->funcionDistancia->getCantidadEvaluaciones() * 100.0
			/ (this->cantidadQueries * this->descriptores->getNumVectores());
	//redondear a un decimal
	double pct = std::round(fraction * 10.0) / 10.0;
	std::cout << "LAESA " << this->cantidadPivotes << " pivotes. queries=" << this->cantidadQueries
			<< ". total distancias=" << this->funcionDistancia->getCantidadEvaluaciones() << " (" << pct << "% del LS)"
			<< std::endl;
}

IndiceLaesa::~IndiceLaesa() {
}
