// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#include <limits>
#include <cmath>
#include <algorithm>
#include "Distancia.hpp"

/* ********************************************* */

Distancia::Distancia() :
		cantidadEvaluaciones(0) {
}

long long Distancia::getCantidadEvaluaciones() {
	return this->cantidadEvaluaciones;
}

void Distancia::resetCantidadEvaluaciones() {
	this->cantidadEvaluaciones = 0;
}

Distancia::~Distancia() {
}

/* ********************************************* */

DistanciaL1::DistanciaL1(int dimensionesVector) :
		dimensionesVectorDiv4(0), dimensionesVectorMod4(0), distanciaUmbral(0) {
	this->dimensionesVectorDiv4 = dimensionesVector / 4;
	this->dimensionesVectorMod4 = dimensionesVector % 4;
	this->resetDistanciaUmbral();
}

void DistanciaL1::setDistanciaUmbral(double distanciaUmbral) {
	this->distanciaUmbral = distanciaUmbral;
}

void DistanciaL1::resetDistanciaUmbral() {
	this->distanciaUmbral = std::numeric_limits<double>::max();
}

double DistanciaL1::distancia(const float *vector1, const float *vector2) {
	this->cantidadEvaluaciones += 1;
	double suma = 0;
	for (int i = 0; i < this->dimensionesVectorDiv4; ++i) {
		double dif1 = std::abs(vector1[0] - vector2[0]);
		double dif2 = std::abs(vector1[1] - vector2[1]);
		double dif3 = std::abs(vector1[2] - vector2[2]);
		double dif4 = std::abs(vector1[3] - vector2[3]);
		suma += dif1 + dif2 + dif3 + dif4;
		if (suma >= this->distanciaUmbral)
			return suma;
		vector1 += 4;
		vector2 += 4;
	}
	for (int i = 0; i < this->dimensionesVectorMod4; ++i) {
		double dif = std::abs(vector1[0] - vector2[0]);
		suma += dif;
		vector1 += 1;
		vector2 += 1;
	}
	return suma;
}

DistanciaL1::~DistanciaL1() {
}

/* ********************************************* */

DistanciaL2::DistanciaL2(int dimensionesVector) :
		dimensionesVectorDiv4(0), dimensionesVectorMod4(0), distanciaUmbral(0), distanciaUmbralAlCuadrado(0) {
	this->dimensionesVectorDiv4 = dimensionesVector / 4;
	this->dimensionesVectorMod4 = dimensionesVector % 4;
	this->resetDistanciaUmbral();
}

void DistanciaL2::setDistanciaUmbral(double distanciaUmbral) {
	this->distanciaUmbral = distanciaUmbral;
	this->distanciaUmbralAlCuadrado = distanciaUmbral * distanciaUmbral;
}

void DistanciaL2::resetDistanciaUmbral() {
	this->distanciaUmbral = this->distanciaUmbralAlCuadrado = std::numeric_limits<double>::max();
}

double DistanciaL2::distancia(const float *vector1, const float *vector2) {
	this->cantidadEvaluaciones += 1;
	double suma = 0;
	for (int i = 0; i < this->dimensionesVectorDiv4; ++i) {
		double dif1 = (vector1[0] - vector2[0]);
		double dif2 = (vector1[1] - vector2[1]);
		double dif3 = (vector1[2] - vector2[2]);
		double dif4 = (vector1[3] - vector2[3]);
		suma += dif1 * dif1 + dif2 * dif2 + dif3 * dif3 + dif4 * dif4;
		if (suma > this->distanciaUmbralAlCuadrado)
			return this->distanciaUmbral;
		vector1 += 4;
		vector2 += 4;
	}
	for (int i = 0; i < this->dimensionesVectorMod4; ++i) {
		double dif = (vector1[0] - vector2[0]);
		suma += dif * dif;
		vector1 += 1;
		vector2 += 1;
	}
	return std::sqrt(suma);
}

DistanciaL2::~DistanciaL2() {
}
/* ********************************************* */

DistanciaLmax::DistanciaLmax(int dimensionesVector) :
		dimensionesVectorDiv4(0), dimensionesVectorMod4(0), distanciaUmbral(0) {
	this->dimensionesVectorDiv4 = dimensionesVector / 4;
	this->dimensionesVectorMod4 = dimensionesVector % 4;
	this->resetDistanciaUmbral();
}

void DistanciaLmax::setDistanciaUmbral(double distanciaUmbral) {
	this->distanciaUmbral = distanciaUmbral;
}

void DistanciaLmax::resetDistanciaUmbral() {
	this->distanciaUmbral = std::numeric_limits<double>::max();
}

double DistanciaLmax::distancia(const float *vector1, const float *vector2) {
	this->cantidadEvaluaciones += 1;
	double maximoGlobal = 0;
	for (int i = 0; i < this->dimensionesVectorDiv4; ++i) {
		double dif1 = std::abs(vector1[0] - vector2[0]);
		double dif2 = std::abs(vector1[1] - vector2[1]);
		double dif3 = std::abs(vector1[2] - vector2[2]);
		double dif4 = std::abs(vector1[3] - vector2[3]);
		double maximo = std::max( { dif1, dif2, dif3, dif4 });
		if (maximo > maximoGlobal) {
			if (maximo >= this->distanciaUmbral)
				return maximo;
			maximoGlobal = maximo;
		}
		vector1 += 4;
		vector2 += 4;
	}
	for (int i = 0; i < this->dimensionesVectorMod4; ++i) {
		double dif = std::abs(vector1[0] - vector2[0]);
		if (dif > maximoGlobal)
			maximoGlobal = dif;
		vector1 += 1;
		vector2 += 1;
	}
	return maximoGlobal;
}

DistanciaLmax::~DistanciaLmax() {
}

/* ********************************************* */

DistanciaLP::DistanciaLP(double orden, int dimensionesVector) :
		orden(orden), dimensionesVectorDiv4(0), dimensionesVectorMod4(0), distanciaUmbral(0), distanciaUmbralP(0) {
	this->dimensionesVectorDiv4 = dimensionesVector / 4;
	this->dimensionesVectorMod4 = dimensionesVector % 4;
	this->resetDistanciaUmbral();
}

void DistanciaLP::setDistanciaUmbral(double distanciaUmbral) {
	this->distanciaUmbral = distanciaUmbral;
	this->distanciaUmbralP = std::pow(distanciaUmbral, orden);
}

void DistanciaLP::resetDistanciaUmbral() {
	this->distanciaUmbral = this->distanciaUmbralP = std::numeric_limits<double>::max();
}

double DistanciaLP::distancia(const float *vector1, const float *vector2) {
	this->cantidadEvaluaciones += 1;
	double suma = 0;
	for (int i = 0; i < this->dimensionesVectorDiv4; ++i) {
		double dif1 = std::abs(vector1[0] - vector2[0]);
		double dif2 = std::abs(vector1[1] - vector2[1]);
		double dif3 = std::abs(vector1[2] - vector2[2]);
		double dif4 = std::abs(vector1[3] - vector2[3]);
		suma += std::pow(dif1, orden) + std::pow(dif2, orden) + std::pow(dif3, orden) + std::pow(dif4, orden);
		if (suma > this->distanciaUmbralP)
			return this->distanciaUmbral;
		vector1 += 4;
		vector2 += 4;
	}
	for (int i = 0; i < this->dimensionesVectorMod4; ++i) {
		double dif = std::abs(vector1[0] - vector2[0]);
		suma += std::pow(dif, orden);
		vector1 += 1;
		vector2 += 1;
	}
	return std::pow(suma, 1.0 / orden);
}

DistanciaLP::~DistanciaLP() {
}

