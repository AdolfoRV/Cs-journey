// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#include <iostream>
#include "IndiceLinearScan.hpp"
#include "ColaPrioridad.hpp"

IndiceLinearScan::IndiceLinearScan() :
		descriptores(nullptr), funcionDistancia(nullptr), cantidadQueries(0) {
}

void IndiceLinearScan::construir(Dataset *descriptores, Distancia *funcionDistancia) {
	this->descriptores = descriptores;
	this->funcionDistancia = funcionDistancia;
}

void IndiceLinearScan::busquedaNN(float *queryVector, int cantidadNN, int *resultadoIds, double *resultadoDistancias) {
	this->cantidadQueries += 1;
	this->funcionDistancia->resetDistanciaUmbral();
	//cola de prioridad (max-heap)
	ColaPrioridad colaPrioridad;
	//recorro los primeros cantidadNN agregándolos a la cola de prioridad
	for (int i = 0; i < cantidadNN && i < this->descriptores->getNumVectores(); ++i) {
		float *vectorR = this->descriptores->getVector(i);
		double distancia = this->funcionDistancia->distancia(queryVector, vectorR);
		//agregarlo a la cola de prioridad
		colaPrioridad.agregar(distancia, i);
	}
	//la cola está llena, el umbral es el candidato de mayor distancia
	double distanciaUmbral = colaPrioridad.topPrioridad();
	this->funcionDistancia->setDistanciaUmbral(distanciaUmbral);
	//recorro desde cantidadNN en adelante
	for (int i = cantidadNN; i < this->descriptores->getNumVectores(); ++i) {
		float *vectorR = this->descriptores->getVector(i);
		double distancia = this->funcionDistancia->distancia(queryVector, vectorR);
		//si la distancia no es mejor que el umbral de corte se descarta el objeto, si no se agrega al heap
		if (distancia >= distanciaUmbral)
			continue;
		//sacar el top del heap (mayor distancia)
		colaPrioridad.borrarTop();
		//agregar el nuevo
		colaPrioridad.agregar(distancia, i);
		//actualizar el umbral con el nuevo top del heap
		distanciaUmbral = colaPrioridad.topPrioridad();
		//actualizar el umbral de corte en la funcion de distancia
		this->funcionDistancia->setDistanciaUmbral(distanciaUmbral);
	}
	//copiar los objetos desde la cola a los array de salida
	colaPrioridad.vaciarCola(resultadoDistancias, resultadoIds);
}

void IndiceLinearScan::imprimirStats() {
	std::cout << "linear scan. queries=" << cantidadQueries << ". total distancias="
			<< this->funcionDistancia->getCantidadEvaluaciones() << std::endl;
}

IndiceLinearScan::~IndiceLinearScan() {
}
