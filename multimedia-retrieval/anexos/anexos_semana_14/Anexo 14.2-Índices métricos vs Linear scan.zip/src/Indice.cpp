// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#include "Indice.hpp"

Indice::Indice() {
}

Indice::~Indice() {
}

