// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#pragma once

class Distancia {
public:
	Distancia();
	virtual void setDistanciaUmbral(double distanciaUmbral) = 0;
	virtual void resetDistanciaUmbral() = 0;
	virtual double distancia(const float *vector1, const float *vector2) = 0;
	virtual long long getCantidadEvaluaciones();
	virtual void resetCantidadEvaluaciones();
	virtual ~Distancia();

protected:
	long long cantidadEvaluaciones;
};

class DistanciaL1: public Distancia {
public:
	DistanciaL1(int dimensionesVector);
	virtual void setDistanciaUmbral(double distanciaUmbral);
	virtual void resetDistanciaUmbral();
	virtual double distancia(const float *vector1, const float *vector2);
	virtual ~DistanciaL1();

private:
	int dimensionesVectorDiv4;
	int dimensionesVectorMod4;
	double distanciaUmbral;
};

class DistanciaL2: public Distancia {
public:
	DistanciaL2(int dimensionesVector);
	virtual void setDistanciaUmbral(double distanciaUmbral);
	virtual void resetDistanciaUmbral();
	virtual double distancia(const float *vector1, const float *vector2);
	virtual ~DistanciaL2();

private:
	int dimensionesVectorDiv4;
	int dimensionesVectorMod4;
	double distanciaUmbral;
	double distanciaUmbralAlCuadrado;
};

class DistanciaLmax: public Distancia {
public:
	DistanciaLmax(int dimensionesVector);
	virtual void setDistanciaUmbral(double distanciaUmbral);
	virtual void resetDistanciaUmbral();
	virtual double distancia(const float *vector1, const float *vector2);
	virtual ~DistanciaLmax();

private:
	int dimensionesVectorDiv4;
	int dimensionesVectorMod4;
	double distanciaUmbral;
};

class DistanciaLP: public Distancia {
public:
	DistanciaLP(double orden, int dimensionesVector);
	virtual void setDistanciaUmbral(double distanciaUmbral);
	virtual void resetDistanciaUmbral();
	virtual double distancia(const float *vector1, const float *vector2);
	virtual ~DistanciaLP();

private:
	double orden;
	int dimensionesVectorDiv4;
	int dimensionesVectorMod4;
	double distanciaUmbral;
	double distanciaUmbralP;
};

