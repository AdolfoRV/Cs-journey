// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#include <stdexcept>
#include <sstream>
#include <iomanip>
#include "ResultadoKnn.hpp"

ResultadoKnn::ResultadoKnn(int cantidadQueries, int cantidadNN) :
		cantidadQueries(cantidadQueries), cantidadNN(cantidadNN) {
	idsNns = std::vector<int>(cantidadQueries * cantidadNN);
	distanciasNns = std::vector<double>(cantidadQueries * cantidadNN);
}

int ResultadoKnn::getCantidadQueries() const {
	return cantidadQueries;
}

int ResultadoKnn::getCantidadNns() const {
	return cantidadNN;
}

int* ResultadoKnn::ids(int numero) {
	if (numero < 0 || numero >= cantidadQueries)
		throw std::runtime_error("fuera de rango " + numero);
	return idsNns.data() + numero * cantidadNN;
}

double* ResultadoKnn::distancias(int numero) {
	if (numero < 0 || numero >= cantidadQueries)
		throw std::runtime_error("fuera de rango " + numero);
	return distanciasNns.data() + numero * cantidadNN;
}

std::string ResultadoKnn::toString(int numero) {
	if (numero < 0 || numero >= cantidadQueries)
		throw std::runtime_error("fuera de rango " + numero);
	int *knnIds = ids(numero);
	double *knnDistancias = distancias(numero);
	std::stringstream ss;
	ss << std::fixed << std::right;
	for (int i = 0; i < cantidadNN; ++i) {
		if (i > 0)
			ss << " ";
		ss << "[" << std::setw(6) << knnIds[i] << "," << std::setw(10) << std::setprecision(5) << knnDistancias[i] << "]";
	}
	return ss.str();
}
