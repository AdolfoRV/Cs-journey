// Ejemplo Implementación y evaluación LAESA
// CC5213 - Recuperación de Información Multimedia
// Profesor: Juan Manuel Barrios
// Fecha: 21 de junio de 2025

#include "helper.hpp"

#include <stdexcept>
#include <fstream>
#include <iostream>
#include <sys/stat.h>
#include "Dataset.hpp"

Dataset* Dataset::cargarDescriptores(const std::string &filename, int dimensiones) {
	if (dimensiones <= 0)
		throw std::runtime_error("dimensiones invalida");
	if (!existeArchivo(filename))
		throw std::runtime_error("no encuentro " + filename);
	std::ifstream infile;
	infile.open(filename, std::ios_base::in | std::ios_base::binary);
	if (!infile.is_open())
		throw std::runtime_error("error abriendo " + filename);
	//posicion al inicio del archivo
	std::ifstream::pos_type currentPosition = infile.tellg();
	//ir al final del archivo y ver la posicion
	infile.seekg(0, std::ios::end);
	std::ifstream::pos_type lastPosition = infile.tellg();
	//contar cuantos bytes hay y cuatos vectores seran
	std::size_t numBytes = lastPosition - currentPosition;
	int numVectores = numBytes / sizeof(float) / dimensiones;
	//verificar que cuadre la cantidad de bytes con los vectores
	if (numBytes != numVectores * dimensiones * sizeof(float))
		throw std::runtime_error(
				std::to_string(numBytes) + " bytes no cuadra con " + std::to_string(dimensiones) + "-d");
	//creo el array de descriptores en memoria
	Dataset *dataset = new Dataset(numVectores, dimensiones);
	//volver al inicio para leer el archivo
	infile.seekg(currentPosition, std::ios::beg);
	//leer los bytes del archivo y escribirlos en memoria
	infile.read(reinterpret_cast<char*>(dataset->getVector(0)), numBytes);
	//verificar que la lectura haya terminado bien
	infile.close();
	if (infile.fail())
		throw std::runtime_error("error al cerrar archivo");
	std::cout << filename << ": " << numVectores << "x" << dimensiones << std::endl;
	return dataset;
}
Dataset::Dataset(int numVectores, int dimensiones) :
		numVectores(numVectores), dimensiones(dimensiones) {
	arrayVectores = new float[numVectores * dimensiones];
}

int Dataset::getNumVectores() const {
	return numVectores;
}

int Dataset::getDimensiones() const {
	return dimensiones;
}

float* Dataset::getVector(int numero) {
	if (numero < 0 || numero >= numVectores)
		throw std::runtime_error("fuera de rango " + numero);
	return arrayVectores + numero * dimensiones;
}

Dataset::~Dataset() {
}
