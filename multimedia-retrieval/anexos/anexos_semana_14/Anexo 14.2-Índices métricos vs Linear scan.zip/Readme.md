# EJEMPLO PIVOTES VS LINEAR SCAN

## CC5213 - Recuperación de Información Multimedia
## Profesor: Juan Manuel Barrios
## Fecha: 21 de junio de 2025

En este ejemplo se muestra que es posible resolver búsquedas exactas del vecino más cercano en menor tiempo que el linear scan. Esto se logra usando un índice métrico que permite obtener el NN real sin tener que compararlos todos contra todos.

 * Primero se usará como referencia la búsqueda knn scan implementada por pyflann con algorithm="linear".

 * Luego se prueba una implementación simple de linear scan hecha en C++ para la búsqueda knn. Notar que esta implementación ya es más rápida que pyflann.

 * Se prueba una implementación de búsqueda knn usando pivotes (selección aleatoria).

Notar que para la comparación se usa un único hilo (cores=1 en pyflann) para que el resultado sea más consistente.
Para un uso real cada consulta se resolvería en un hilo independiente para aprovechar los múltiples cores del procesador.

Se incluyen dos datasets para probar, llamados "dataset_a" y "dataset_b".
Notar que en el conjunto "dataset_a" se obtiene mayor ganancia de tiempo usando varios pivotes.
En "dataset_b" hay que usar unos pocos pivotes para lograr ser un poco más rápido que el linear scan.
En el material docente se pueden ver razones de por qué puede suceder este comportamiento.


  1. Para tomar un tiempo de referencia primero usar el linear scan de pyflann:

```
python LinearScan.py "dataset_a_q-128d.bin" "dataset_a_r-128d.bin" 128 1
```
    En mi computador el tiempo de búsqueda fue de 19.7 segundos.


  2. Compilar el código en C++ con "make" (ver Semana 01 para configurar el ambiente de compilación).


  3. Usar linear scan de C++ con el conjunto "dataset_a":

```
./ejemplo_pivotes -q "dataset_a_q-128d.bin" -r "dataset_a_r-128d.bin" -dim 128 -dist L2 -knn 1 -indice LINEAR
```
    En mi computador tiene tiempo búsqueda 15.9 segundos (un poco más rápido que pyflann).
    Debiera demorar el mismo tiempo que pyflann.
	Probablemente este linear scan es más rápido que pyflann por la implementación de la función de distancia.
    Ver src/Distancia.cpp que tiene una buena implementación de distancia euclidiana.


  4. Buscar usando 5 pivotes con el conjunto "dataset_a" (verificar que el tiempo de búsqueda es menor y que resultado es igual al linear scan):

```
./ejemplo_pivotes -q "dataset_a_q-128d.bin" -r "dataset_a_r-128d.bin" -dim 128 -dist L2 -knn 1 -indice LAESA_5
```
    En mi computador tiene tiempo búsqueda 14.9 segundos (un poco más rápido que linear scan).
	Si bien los pivotes descartan cerca del 60% de distancias, la complejidad interna hace que el tiempo baje cerca de un 10%.

  5. Probar con el "dataset_b". En este conjunto la ganancia es poca por lo que se debe probar con unos pocos pivotes (1 o 2).
 
```
python LinearScan.py "dataset_b_q-128d.bin" "dataset_b_r-128d.bin" 128 1
  ->tiempo busqueda (pyflann linear scan): 20.9 segundos

./ejemplo_pivotes -q "dataset_b_q-128d.bin" -r "dataset_b_r-128d.bin" -dim 128 -dist L2 -knn 1 -indice LINEAR
  ->tiempo busqueda (linear scan): 17.7 segundos

./ejemplo_pivotes -q "dataset_b_q-128d.bin" -r "dataset_b_r-128d.bin" -dim 128 -dist L2 -knn 1 -indice LAESA_1
   ->tiempo busqueda (con 1 pivote): 17.0 segundos

./ejemplo_pivotes -q "dataset_b_q-128d.bin" -r "dataset_b_r-128d.bin" -dim 128 -dist L2 -knn 1 -indice LAESA_2
   ->tiempo busqueda (con 2 pivotes): 18.3 segundos
```


Hay que recordar que está escogiendo pivotes al azar, por lo que es posible obtener malos pivotes y la búsqueda con pivotes
puede resultar ser más lenta que linear scan. Por esto, puede ser necesario hacer varios intentos para obtener un buen
conjunto de pivotes.
En el material docente se revisan algoritmos robustos para selección de pivotes.
