# CC5213 - Recuperación de Información Multimedia
# Profesor: Juan Manuel Barrios
# Fecha: 21 de junio de 2025

import os
import sys
import math
import time
import numpy
import pyflann


def load_binary_file(filename, dimensions):
    assert os.path.isfile(filename), "no existe archivo " + filename
    mat = numpy.fromfile(filename, dtype=numpy.float32)
    return numpy.reshape(mat, (-1, dimensions))


def imprimir_resultado(nns, dists, segundos, cantidad_nns):
    print("linear scan = {:.1f} segundos".format(segundos))
    for i in range(10):
        linea = str(i)
        # se imprime la raiz de la distancia porque por defecto usa distancia euclidiana al cuadrado
        if cantidad_nns == 1:
            linea += " [{:6d},{:>10.5f}]".format(nns[i], math.sqrt(dists[i]))
        else:
            for k in range(cantidad_nns):
                linea += " [{:6d},{:>10.5f}]".format(nns[i][k], math.sqrt(dists[i][k]))
        print(linea)


def linear_scan(dataset_q, dataset_r, cantidad_nns):
    # crea un objeto flann
    flann = pyflann.FLANN()
    # construir el indice para linear scan
    flann.build_index(dataset_r, algorithm="linear")
    # por defecto pyflann usa distancia euclidiana al cuadrado, se puede cambiar con set_distance_type
    # pyflann.set_distance_type("minkowski", 2)
    # ejecutar el linear scan
    t0 = time.time()
    nns, dists = flann.nn_index(dataset_q, num_neighbors=cantidad_nns, cores=1)
    segundos = time.time() - t0
    imprimir_resultado(nns, dists, segundos, cantidad_nns)


def main():
    if len(sys.argv) < 4:
        print("CC5213 - Evaluación LINEAR SCAN")
        print(
            "uso: {} [descriptoresQ] [descriptoresR] [dimensiones] [cantidadNN]".format(
                sys.argv[0]
            )
        )
        sys.exit(1)
    file_q = sys.argv[1]
    file_r = sys.argv[2]
    dimensiones = int(sys.argv[3])
    cantidad_nns = int(sys.argv[4])
    # cargar el conjunto de vectores
    dataset_q = load_binary_file(file_q, dimensiones)
    print("{}: Q={}".format(file_q, dataset_q.shape))
    dataset_r = load_binary_file(file_r, dimensiones)
    print("{}: R={}".format(file_r, dataset_r.shape))
    # ejecutar la busqueda
    linear_scan(dataset_q, dataset_r, cantidad_nns)


# método main
if __name__ == "__main__":
    main()
